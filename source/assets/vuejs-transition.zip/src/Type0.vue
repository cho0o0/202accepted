<template>
<div id="type0">
  <transition name="fade">
    <content-placeholders v-if="text === null">
      <content-placeholders-heading :img="true"></content-placeholders-heading>
    </content-placeholders>
    <my-content v-else :img="img" :title="title" :text="text">
    </my-content>
  </transition>
</div>
</template>

<script>
import MyContent from './MyContent.vue';

export default {
  name: 'type0',
  components: {
    MyContent
  },
  mounted() {
    const retrieveData = async () => {
      const res = await fetch('https://jsonplaceholder.typicode.com/photos');
      const val = await res.json().then(data => data[0]);
      Object.assign(this, {
        img: val.thumbnailUrl,
        title: val.title,
        text: val.url
      });
    };
    setTimeout(retrieveData, 3000);
  },
  data() {
    return {
      img: null,
      title: null,
      text: null,
    };
  },
};
</script>

<style>
.fade-enter-active {
  transition: opacity 1s;
}

.fade-leave-active {
  transition: opacity 1s;
}

.fade-enter, .fade-leave-to  {
  opacity: 0
}
</style>
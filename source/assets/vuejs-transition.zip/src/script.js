import Vue from 'vue';
import VueContentPlaceholders from 'vue-content-placeholders';
import MyComponent from './Main.vue';

Vue.use(VueContentPlaceholders);

new Vue ({
  el: '#app',
  components: {
    'my-component': MyComponent
  }
});
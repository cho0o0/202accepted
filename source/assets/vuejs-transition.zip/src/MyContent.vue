<template>
  <div>
    <div class="vue-content-placeholders-heading">
      <img class="vue-content-placeholders-heading__img" :src="img">
      <div class="vue-content-placeholders-heading__content">
        <div class="vue-content-placeholders-heading__title my-title">{{ title }}</div>
        <div class="vue-content-placeholders-heading__subtitle my-text">{{ text }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'my-content',
  props: {
    img: String,
    title: String,
    text: String,
  },
};
</script>

<style>
.my-title, .my-text {
  background-color: white;
  font-size: 10px;
}
</style>
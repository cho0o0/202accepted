<template>
  <div>
    <div class="controller-zone">
      <select v-model="selected">
        <option disabled value="">Transition Type</option>
        <option>None</option>
        <option>0</option>
        <option>1</option>
        <option>2</option>
      </select>
    </div>
    <div class="display-zone">
      <none v-if="selected === 'None'"></none>
      <type0 v-if="selected === '0'"></type0>
      <type1 v-if="selected === '1'"></type1>
      <type2 v-if="selected === '2'"></type2>
    </div>
    <div>----------------------------</div>
  </div>
</template>

<script>
import none from './NoTransition.vue';
import type0 from './Type0.vue';
import type1 from './Type1.vue';
import type2 from './Type2.vue';  
  
export default {
  components: {
    none, type0, type1, type2
  },
  data() {
    return {
      selected: '',
    };
  },
};
</script>

<style>
.controller-zone {
  margin: 2rem;
  position: fixed;
  bottom: 50px;
}
</style>